// 顶层构建脚本：只声明插件，不写具体构建逻辑
// 版本组合：AGP 8.7.3 + Gradle 8.11.1 + Kotlin 1.9.24 + JDK 17
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
