# 本项目不启用混淆，保留默认规则即可
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * extends android.accessibilityservice.AccessibilityService { *; }
