package com.ujn.autodroid.core

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityNodeInfo
import com.ujn.autodroid.model.AppProfile
import com.ujn.autodroid.model.Target
import com.ujn.autodroid.model.TaskConfig
import com.ujn.autodroid.service.AutoService
import com.ujn.autodroid.util.Humanizer
import com.ujn.autodroid.util.LogBus
import java.io.File
import kotlin.math.max

/**
 * 自动化流程引擎：
 *   启动 App → 搜索关键词 → 进第一个视频 → 循环(点赞 / 评论 → 下一个) → 返回
 *
 * 风控缓解措施分布：
 *   P0 节奏：所有等待走对数正态分布；点击走高斯抖动落点；滑动走贝塞尔曲线
 *   P1 行为：进入视频后先随机"观看"；动作组合随机（都做/只赞/只评/都跳过）
 *   P2 策略：运行时段、会话休息、单日配额、评论去重
 */
class TaskEngine(private val service: AutoService) {

    companion object {
        /** 评论长度上限，多数平台在 100~150 字之间，这里保守取 100 */
        private const val COMMENT_MAX_LEN = 100
    }

    @Volatile
    var stopped = false

    private lateinit var logFile: File
    private var screenW = 1080
    private var screenH = 1920

    private val policy = PolicyController(service)

    var likeCount = 0
        private set
    var commentCount = 0
        private set
    var skipCount = 0
        private set

    /** 本轮已经用过的评论文案，用于去重 */
    private val usedComments = mutableSetOf<String>()

    /** 上一条实际发出的评论文案，用于避免相邻重复 */
    private var lastComment: String? = null

    /** 是否成功拉起过目标 App（决定收尾时是否需要清理页面栈） */
    @Volatile
    private var enteredTargetApp = false

    fun run(cfg: TaskConfig, profile: AppProfile) {
        logFile = File(service.filesDir, "autodroid.log")
        val dm = DisplayMetrics()
        runCatching {
            (service.getSystemService(AccessibilityService.WINDOW_SERVICE) as android.view.WindowManager)
                .defaultDisplay.getMetrics(dm)
        }
        if (dm.widthPixels > 0) {
            screenW = dm.widthPixels
            screenH = dm.heightPixels
        }

        LogBus.log(
            "任务开始：App=${profile.name}(${profile.pkg}) 关键词=${cfg.keywords.size} " +
                "点赞=${cfg.doLike} 评论=${cfg.doComment} 试运行=${cfg.dryRun}", logFile
        )
        LogBus.log("节奏参数：间隔中位数 ${cfg.delayMedianMs}ms（对数正态，sigma=${cfg.delaySigma}）", logFile)
        LogBus.log("行为参数：观看 ${cfg.watchMinMs}~${cfg.watchMaxMs}ms，划走概率 ${pct(cfg.skipVideoProb)}，逐字输入=${cfg.typeCharByChar}", logFile)
        LogBus.log("策略参数：${policy.quotaSummary(cfg)}" +
            if (cfg.respectTimeWindow) "，运行时段 ${cfg.hourFrom}:00-${cfg.hourTo}:00" else "，不限时段",
            logFile)
        if (cfg.uniqueComment) LogBus.log("评论去重：已开启", logFile)
        if (cfg.dryRun) LogBus.log("试运行模式：只记录流程，不会真的点赞/发送", logFile)

        try {
            // ---- P2：运行时段检查 ----
            if (!policy.inTimeWindow(cfg)) {
                val waitMs = policy.msUntilWindowOpen(cfg)
                LogBus.log("当前不在允许的运行时段（${cfg.hourFrom}:00-${cfg.hourTo}:00），任务取消。" +
                    "距离时段开放约 ${waitMs / 60000} 分钟", logFile)
                return
            }

            outer@ for (round in 1..max(1, cfg.loopCount)) {
                if (stopped) break
                LogBus.log("──────── 第 $round/${cfg.loopCount} 轮 ────────", logFile)
                for (kw in cfg.keywords) {
                    if (stopped) break
                    if (kw.isBlank()) continue

                    // ---- P2：单日配额检查 ----
                    if (quotaStop(cfg)) break@outer

                    // ---- P2：会话休息 ----
                    if (policy.needBreak(cfg)) {
                        val restSec = cfg.breakMinutes * 60
                        LogBus.log("已连续运行 ${policy.sessionElapsedSec() / 60} 分钟，" +
                            "进入 ${cfg.breakMinutes} 分钟休息（拟人化会话节奏）", logFile)
                        if (!sleepInterruptible(restSec * 1000L)) {
                            LogBus.log("休息期间收到停止指令", logFile)
                            break@outer
                        }
                        policy.resetSession()
                        LogBus.log("休息结束，继续（累计已休息 ${policy.breakCount} 次）", logFile)
                    }

                    LogBus.log("【关键词】$kw", logFile)
                    val ok = openAndSearch(cfg, profile, kw)
                    if (!ok) {
                        LogBus.log("× 未能进入视频页，跳过该关键词", logFile)
                        backTimes(2, 400L)
                        continue
                    }
                    handleVideos(cfg, profile, kw)
                    LogBus.log("返回首页，准备下一个关键词", logFile)
                    backToHome(profile)
                }
            }
        } catch (e: Exception) {
            LogBus.log("!! 异常中断：${e.message}", logFile)
        } finally {
            // 无论正常结束、被停止还是异常退出，都要把页面栈退回首页，
            // 否则下次启动任务时会停在搜索页/视频页，导致后续控件全都找不到。
            if (enteredTargetApp) {
                LogBus.log("收尾：返回首页", logFile)
                backToHome(profile)
            }
            LogBus.log(
                "任务结束：点赞 $likeCount 次，评论 $commentCount 次，跳过 $skipCount 个视频",
                logFile
            )
            LogBus.log(policy.quotaSummary(cfg), logFile)
            service.onTaskFinished()
        }
    }

    /** 配额是否已全部用完 */
    private fun quotaStop(cfg: TaskConfig): Boolean {
        val likeOut = cfg.doLike && policy.likeQuotaExhausted(cfg)
        val commentOut = cfg.doComment && policy.commentQuotaExhausted(cfg)
        // 只勾了点赞且点赞用完了 → 停；只勾了评论且评论用完了 → 停；两个都勾 → 都完成才停
        val stop = when {
            cfg.doLike && cfg.doComment -> likeOut && commentOut
            cfg.doLike -> likeOut
            cfg.doComment -> commentOut
            else -> true
        }
        if (stop) {
            LogBus.log("已触及单日配额上限，任务停止（${policy.quotaSummary(cfg)}）", logFile)
        }
        return stop
    }

    /** 启动 App 并搜索关键词，进入第一个视频 */
    private fun openAndSearch(cfg: TaskConfig, profile: AppProfile, kw: String): Boolean {
        val pkg = cfg.pkg.ifBlank { profile.pkg }
        if (pkg.isBlank()) {
            LogBus.log("× 未配置目标 App 包名", logFile)
            return false
        }

        if (!launchApp(pkg)) {
            LogBus.log("× 启动失败，包名不存在：$pkg", logFile)
            return false
        }
        enteredTargetApp = true
        sleep(profile.launchWaitMs)

        var inApp = false
        for (i in 0 until 5) {
            val p = service.rootInActiveWindow?.packageName?.toString()
            if (p == pkg) { inApp = true; break }
            sleep(800)
        }
        if (!inApp) {
            LogBus.log("! 等待 4s 仍未检测到目标 App 在前台，继续尝试", logFile)
        }

        // App 若已在后台，launchIntent 只会"恢复"到离开时的页面，可能停在视频页/搜索页。
        // 先尝试退回首页，否则后面找不到搜索入口。多轮任务时这一步尤其关键。
        if (!waitForHomeScreen(profile, 2500L)) {
            LogBus.log("· 当前不在首页，尝试退回", logFile)
            backTimes(profile.backToHome, 600L)
            if (!waitForHomeScreen(profile, 2000L)) {
                LogBus.log("! 仍未回到首页，继续按流程尝试", logFile)
            }
        }

        // 1) 点搜索入口
        if (profile.searchEntry != null) {
            val nodes = NodeFinder.waitFor(service, profile.searchEntry, 8000)
            if (nodes.isEmpty()) {
                LogBus.log("× 找不到搜索入口：${profile.searchEntry.values}", logFile)
                return false
            }
            NodeFinder.click(service, pick(nodes, profile.searchEntry))
            recycle(nodes)
            LogBus.log("· 已点击搜索入口", logFile)
            randomDelay(cfg)
        }

        // 2) 输入关键词
        var box: AccessibilityNodeInfo? = null
        var boxOwned = false   // true 表示来自 findEditable，需自行回收
        if (profile.searchBox != null) {
            val nodes = NodeFinder.waitFor(service, profile.searchBox, 6000)
            if (nodes.isNotEmpty()) box = pick(nodes, profile.searchBox!!)
            recycle(nodes)
        }
        if (box == null) {
            for (i in 0 until 10) {
                box = NodeFinder.findEditable(service)
                if (box != null) {
                    boxOwned = true
                    break
                }
                sleep(500)
            }
        }
        if (box == null) {
            LogBus.log("× 找不到搜索输入框（可在自定义模板里配置 searchBox）", logFile)
            return false
        }
        try {
            if (!inputKeyword(box, kw, cfg.typeCharByChar)) {
                LogBus.log("× 关键词输入失败：" + kw, logFile)
                return false
            }
        } finally {
            if (boxOwned) recycleOne(box)
        }
        LogBus.log("· 已输入关键词：$kw", logFile)
        sleep(600)

        // 3) 触发搜索
        var searched = false
        if (profile.searchGo != null) {
            val nodes = NodeFinder.waitFor(service, profile.searchGo, 4000)
            if (nodes.isNotEmpty()) {
                searched = NodeFinder.click(service, pick(nodes, profile.searchGo!!))
                recycle(nodes)
            }
        }
        if (!searched && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = NodeFinder.findEditable(service)
            if (b != null) {
                searched = b.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                b.recycle()
            }
        }
        if (!searched) LogBus.log("! 没找到搜索按钮，等待结果自行加载", logFile)
        sleep(humanMs(2500L))

        // 4) 结果页切到"视频"tab
        if (profile.resultTab != null) {
            val nodes = NodeFinder.waitFor(service, profile.resultTab, 4000)
            if (nodes.isNotEmpty()) {
                NodeFinder.click(service, pick(nodes, profile.resultTab!!))
                recycle(nodes)
                randomDelay(cfg)
            }
        }

        // 5) 进第一个视频
        var entered = false
        if (profile.firstResult != null) {
            val nodes = NodeFinder.waitFor(service, profile.firstResult, 5000)
            if (nodes.isNotEmpty()) {
                entered = NodeFinder.click(service, pick(nodes, profile.firstResult!!))
                recycle(nodes)
            }
        }
        if (!entered) {
            // 兜底坐标点击也加抖动，不要永远点同一个像素
            val (jx, jy) = Humanizer.jitteredPoint(
                0, 0, screenW, screenH, sigmaRatio = 0.06
            )
            val x = (screenW * profile.resultX + (jx - screenW / 2) * 0.15f).toInt()
            val y = (screenH * profile.resultY + (jy - screenH / 2) * 0.15f).toInt()
            entered = NodeFinder.tap(service, x, y)
        }
        if (!entered) {
            LogBus.log("× 无法点击搜索结果", logFile)
            return false
        }
        sleep(humanMs(2500L))

        // 6) 校验是否真的进了视频播放页
        val markers = ArrayList<Target>()
        profile.like?.let { markers.add(it) }
        profile.commentEntry?.let { markers.add(it) }
        if (markers.isNotEmpty()) {
            val node = NodeFinder.waitAny(service, markers, 6000)
            if (node == null) {
                NodeFinder.tap(service, (screenW * 0.5f).toInt(), (screenH * 0.45f).toInt())
                sleep(humanMs(2000L))
                val n2 = NodeFinder.waitAny(service, markers, 5000)
                if (n2 == null) {
                    LogBus.log("× 没检测到视频页特征控件（点赞/评论按钮），可能没进视频", logFile)
                    return false
                }
                n2.recycle()
            } else {
                node.recycle()
            }
        }
        LogBus.log("· 已进入视频页", logFile)
        return true
    }

    /** 逐个视频执行点赞/评论 */
    private fun handleVideos(cfg: TaskConfig, profile: AppProfile, kw: String) {
        var fail = 0
        for (i in 1..max(1, cfg.videosPerKeyword)) {
            if (stopped) break
            if (fail >= max(1, cfg.maxFail)) {
                LogBus.log("× 连续失败 $fail 次，放弃该关键词", logFile)
                break
            }
            if (quotaStop(cfg)) break

            LogBus.log("· 第 $i/${cfg.videosPerKeyword} 个视频", logFile)

            // ---- P1：先"看"一会儿，而不是进去就点 ----
            val watchMs = Humanizer.between(cfg.watchMinMs, max(cfg.watchMinMs, cfg.watchMaxMs))
            LogBus.log("  （观看 ${watchMs / 1000.0}s）", logFile)
            if (!sleepInterruptible(watchMs)) break

            // ---- P1：有的视频直接划走，什么都不做 ----
            if (Humanizer.chance(cfg.skipVideoProb)) {
                skipCount++
                LogBus.log("  · 这个不感兴趣，直接划走", logFile)
                if (i < cfg.videosPerKeyword && !stopped) {
                    // 划走也算一次成功的页面切换，成功后要重置失败计数
                    if (nextVideo(profile)) fail = 0 else fail++
                    sleep(humanMs(1500L))
                }
                continue
            }

            // ---- P1：随机决定这个视频做什么，而不是固定顺序 ----
            val plan = planActions(cfg)

            if (plan.contains(Action.LIKE)) {
                if (doLike(cfg, profile)) fail = 0 else fail++
                randomDelay(cfg)
            }
            if (plan.contains(Action.COMMENT) && !stopped) {
                // 评论前再"看"一眼评论区的时间
                if (!sleepInterruptible(Humanizer.between(800L, 2500L))) break
                if (doComment(cfg, profile, kw)) fail = 0 else fail++
                randomDelay(cfg)
            }

            if (i < cfg.videosPerKeyword && !stopped) {
                if (nextVideo(profile)) {
                    fail = 0
                } else {
                    LogBus.log("× 切换下一个视频失败", logFile)
                    fail++
                }
                sleep(humanMs(1500L))
            }
        }
    }

    private enum class Action { LIKE, COMMENT }

    /** P1：按概率决定这次做哪些动作，避免"每个视频都全套"这种固定模式 */
    private fun planActions(cfg: TaskConfig): Set<Action> {
        val out = mutableSetOf<Action>()
        when {
            cfg.doLike && cfg.doComment -> {
                // 都勾选时：只赞 / 只评 / 都做，按配置概率分流。
                // 用户可能把概率之和设成 >1（比如 0.8 + 0.6），此时必须归一化，
                // 否则"只评论"区间会被挤掉、"都做"永远不会命中。
                var pLike = cfg.onlyLikeProb.coerceIn(0.0, 1.0)
                var pComment = cfg.onlyCommentProb.coerceIn(0.0, 1.0)
                val sum = pLike + pComment
                if (sum > 1.0) {
                    pLike /= sum
                    pComment /= sum
                }
                val r = Humanizer.betweenDouble(0.0, 1.0)
                when {
                    r < pLike -> out.add(Action.LIKE)
                    r < pLike + pComment -> out.add(Action.COMMENT)
                    else -> { out.add(Action.LIKE); out.add(Action.COMMENT) }
                }
            }
            cfg.doLike -> out.add(Action.LIKE)
            cfg.doComment -> out.add(Action.COMMENT)
        }
        return out
    }

    private fun doLike(cfg: TaskConfig, profile: AppProfile): Boolean {
        val t = profile.like
        if (t == null) {
            LogBus.log("× 模板未配置点赞按钮（like）", logFile)
            return false
        }
        if (policy.likeQuotaExhausted(cfg)) {
            LogBus.log("· 今日点赞已达上限，跳过", logFile)
            return true
        }
        val nodes = NodeFinder.waitFor(service, t, 4000)
        if (nodes.isEmpty()) {
            LogBus.log("× 找不到点赞按钮：${t.values}", logFile)
            return false
        }
        val node = pick(nodes, t)
        val sig = NodeFinder.signature(node)
        if (cfg.skipIfLiked && profile.likedHints.any { sig.contains(it, true) }) {
            LogBus.log("· 检测到已点赞（$sig），跳过", logFile)
            recycle(nodes)
            return true
        }
        if (cfg.dryRun) {
            LogBus.log("· [试运行] 将点赞", logFile)
            recycle(nodes)
            return true
        }
        val ok = NodeFinder.click(service, node)
        recycle(nodes)
        if (ok) {
            likeCount++
            policy.addLike()
            LogBus.log("√ 点赞成功（本次 $likeCount，${policy.quotaSummary(cfg)}）", logFile)
        } else {
            LogBus.log("× 点赞点击失败", logFile)
        }
        return ok
    }

    private fun doComment(cfg: TaskConfig, profile: AppProfile, kw: String): Boolean {
        val entry = profile.commentEntry
        if (entry == null) {
            LogBus.log("× 模板未配置评论入口（commentEntry）", logFile)
            return false
        }
        if (policy.commentQuotaExhausted(cfg)) {
            LogBus.log("· 今日评论已达上限，跳过", logFile)
            return true
        }
        val nodes = NodeFinder.waitFor(service, entry, 4000)
        if (nodes.isEmpty()) {
            LogBus.log("× 找不到评论入口：${entry.values}", logFile)
            return false
        }
        NodeFinder.click(service, pick(nodes, entry))
        recycle(nodes)
        sleep(humanMs(1800L))

        var box: AccessibilityNodeInfo? = null
        var boxOwned = false   // true 表示 box 是 findEditable 单独取到的，需要我们自己回收
        if (profile.commentBox != null) {
            val bs = NodeFinder.waitFor(service, profile.commentBox, 5000)
            if (bs.isNotEmpty()) box = pick(bs, profile.commentBox!!)
            recycle(bs)
        }
        if (box == null) {
            for (i in 0 until 10) {
                box = NodeFinder.findEditable(service)
                if (box != null) {
                    boxOwned = true
                    break
                }
                sleep(500)
            }
        }
        if (box == null) {
            LogBus.log("× 找不到评论输入框", logFile)
            closeCommentPanel(profile)
            return false
        }

        try {
            // ---- P2：评论内容去重 + 自然化 ----
            val raw = policy.pickComment(cfg.comments, usedComments, cfg.uniqueComment, lastComment) ?: "不错"
            val content = policy.naturalize(raw.replace("{keyword}", kw), maxLen = COMMENT_MAX_LEN)
            usedComments.add(raw)
            lastComment = raw

            if (!inputText(box, content, cfg.typeCharByChar)) {
                LogBus.log("× 评论内容输入失败", logFile)
                return false
            }

            if (cfg.dryRun) {
                LogBus.log("· [试运行] 将发送评论：$content", logFile)
                return true
            }

            var sent = false
            if (profile.commentSend != null) {
                val sn = NodeFinder.waitFor(service, profile.commentSend, 4000)
                if (sn.isNotEmpty()) {
                    sent = NodeFinder.click(service, pick(sn, profile.commentSend!!))
                    recycle(sn)
                }
            }
            sleep(humanMs(1200L))
            if (sent) {
                commentCount++
                policy.addComment()
                LogBus.log("√ 评论发送成功（本次 $commentCount，${policy.quotaSummary(cfg)}）：$content", logFile)
            } else {
                LogBus.log("× 没找到发送按钮，评论可能未发出", logFile)
            }
            return sent
        } finally {
            // box 若来自 findEditable 则由我们回收；来自 waitFor 已随列表回收，不能重复回收
            if (boxOwned) recycleOne(box)
            closeCommentPanel(profile)
        }
    }

    private fun nextVideo(profile: AppProfile): Boolean =
        if (profile.swipeNext) {
            NodeFinder.swipeUp(service, screenW, screenH)
        } else {
            val t = profile.nextVideo
            if (t == null) {
                NodeFinder.swipeUp(service, screenW, screenH)
            } else {
                val nodes = NodeFinder.waitFor(service, t, 3000)
                if (nodes.isEmpty()) false else {
                    val r = NodeFinder.click(service, pick(nodes, t))
                    recycle(nodes)
                    r
                }
            }
        }

    // ---------- 输入 ----------

    /** P1：逐字输入，带随机节奏；关闭时退化为一次性写入 */
    private fun inputKeyword(box: AccessibilityNodeInfo, text: String, charByChar: Boolean): Boolean =
        inputText(box, text, charByChar)

    /**
     * 逐字输入。
     * 关键点：逐字输入耗时长（一句话可能 2~5 秒），期间键盘弹起、页面重排都可能让
     * 之前拿到的节点失效，直接继续用它 performAction 会静默失败。
     * 所以每次写入前都校验节点存活，失效了就重新取一个可编辑控件。
     */
    private fun inputText(
        box: AccessibilityNodeInfo,
        text: String,
        charByChar: Boolean
    ): Boolean {
        if (!charByChar) {
            return NodeFinder.inputText(service, box, text)
        }

        runCatching { box.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
        sleep(200)
        NodeFinder.clearText(service, box)

        // 当前持有的输入框节点，可能在中途被替换成新取的
        var cur = box

        fun ensureAlive(): AccessibilityNodeInfo? {
            if (isAlive(cur)) return cur
            val fresh = NodeFinder.findEditable(service) ?: return null
            // 新节点由我们负责回收（调用方只知道原始的 box）
            runCatching { cur.recycle() }
            cur = fresh
            return cur
        }

        val batches = Humanizer.typingBatches(text)
        val sb = StringBuilder()
        for ((chunk, delay) in batches) {
            if (stopped) return sb.isNotEmpty()
            sb.append(chunk)
            val target = ensureAlive() ?: return NodeFinder.inputText(service, box, text)
            if (!NodeFinder.appendText(service, target, sb.toString())) {
                // 追加失败就退回一次性写入
                return NodeFinder.inputText(service, target, text)
            }
            sleep(delay)
        }
        // 低概率模拟"发现打错了，删一个字再补回来"
        if (Humanizer.chance(0.08) && text.length >= 3) {
            val target = ensureAlive()
            if (target != null && sb.length >= 2) {
                val trimmed = sb.substring(0, sb.length - 1)
                NodeFinder.setText(service, target, trimmed)
                sleep(Humanizer.logNormalMs(320L, 0.4))
                sb.append(text.last())
                NodeFinder.setText(service, target, sb.toString())
            }
        }
        return true
    }

    /** 节点是否仍然可用（被回收或失效后 getText 会异常，用 try 判定） */
    private fun isAlive(node: AccessibilityNodeInfo): Boolean =
        runCatching { node.getChildCount(); true }.getOrDefault(false)

    /**
     * 判断并等待 App 首页出现。
     *
     * 纯靠"搜索入口存在"不够准——搜索结果页往往也有搜索框。
     * 所以用组合特征：搜索入口存在 且 播放页特征（点赞/评论按钮）不存在。
     * 模板没配搜索入口时无法判定，直接返回 true 不做拦截，避免误伤。
     */
    private fun waitForHomeScreen(profile: AppProfile, timeoutMs: Long): Boolean {
        val entry = profile.searchEntry ?: return true
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            val hasEntry = NodeFinder.waitFor(service, entry, 400, 200).let {
                val ok = it.isNotEmpty()
                recycle(it)
                ok
            }
            if (hasEntry) {
                // 再确认不是播放页
                val markers = ArrayList<Target>()
                profile.like?.let { markers.add(it) }
                profile.commentEntry?.let { markers.add(it) }
                var onPlayer = false
                if (markers.isNotEmpty()) {
                    markers.forEach { t ->
                        val l = NodeFinder.findOnce(service, t)
                        if (l.isNotEmpty()) {
                            onPlayer = true
                            recycle(l)
                        }
                    }
                }
                if (!onPlayer) return true
            }
            if (stopped) return false
            sleep(300)
        }
        return false
    }

    private fun launchApp(pkg: String): Boolean {
        val intent = service.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return runCatching { service.startActivity(intent); true }.getOrDefault(false)
    }

    private fun back() {
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    /**
     * 从候选列表里选中一个节点。
     * 返回的节点仍然属于 [list]，调用方应按原逻辑统一 recycle(list)，
     * 不要单独 recycle 返回值（单节点 findEditable 的结果除外）。
     */
    private fun pick(list: List<AccessibilityNodeInfo>, t: Target): AccessibilityNodeInfo =
        list[if (t.index in list.indices) t.index else 0]

    /** 回收 waitFor 返回的节点列表 */
    private fun recycle(list: List<AccessibilityNodeInfo>) {
        list.forEach { runCatching { it.recycle() } }
    }

    /** 回收单个节点（用于 findEditable 这类单节点结果） */
    private fun recycleOne(node: AccessibilityNodeInfo?) {
        node?.let { runCatching { it.recycle() } }
    }

    /**
     * 普通等待。
     * 注意：停止时直接返回是刻意的——但调用方如果靠它来"控制节奏"（比如 back() 之间的间隔），
     * 收尾阶段应该用 sleepAnyway，否则返回键会被连按、页面栈错乱。
     */
    private fun sleep(ms: Long) {
        if (stopped) return
        SystemClock.sleep(ms)
    }

    /** 收尾阶段用的等待：即使已停止也要把间隔走完，保证清理动作按节奏执行 */
    private fun sleepAnyway(ms: Long) {
        val step = 200L
        var remain = ms
        while (remain > 0) {
            SystemClock.sleep(minOf(remain, step))
            remain -= step
        }
    }

    /** 返回首页：按 backToHome 次数逐次返回，间隔固定走完，不受停止状态影响 */
    private fun backToHome(profile: AppProfile) = backTimes(profile.backToHome, 500L)

    /** 收起评论面板：按 afterCommentBack 次数返回 */
    private fun closeCommentPanel(profile: AppProfile) = backTimes(profile.afterCommentBack, 400L)

    /** 连按 n 次返回键，每次之间固定等待（停止状态下也要把间隔走完，避免连按打乱页面栈） */
    private fun backTimes(n: Int, gapMs: Long) {
        repeat(n.coerceAtLeast(0)) {
            back()
            sleepAnyway(gapMs)
        }
    }

    /** 可被打断的长睡眠，返回 false 表示中途被停止 */
    private fun sleepInterruptible(ms: Long): Boolean {
        var remain = ms
        while (remain > 0) {
            if (stopped) return false
            val step = minOf(remain, 500L)
            SystemClock.sleep(step)
            remain -= step
        }
        return !stopped
    }

    /** P0：按对数正态分布采样一次操作间隔 */
    private fun humanMs(median: Long): Long = Humanizer.logNormalMs(median, 0.5)

    /** P0：行动之间的间隔，围绕配置的中位数做对数正态波动 */
    private fun randomDelay(cfg: TaskConfig) {
        val ms = Humanizer.logNormalMs(cfg.delayMedianMs, cfg.delaySigma)
        sleep(ms)
    }

    private fun pct(v: Double): String = "${(v * 100).toInt()}%"
}
