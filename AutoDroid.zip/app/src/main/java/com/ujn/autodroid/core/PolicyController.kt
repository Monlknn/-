package com.ujn.autodroid.core

import android.content.Context
import com.ujn.autodroid.model.TaskConfig
import com.ujn.autodroid.util.Humanizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 策略层：运行时段、会话休息、单日配额。
 *
 * 这些是"控制总量"的手段，比单纯调慢速度更能降低风险——
 * 平台的风控模型里，单位时间的操作密度和单日总量都是强特征。
 */
class PolicyController(private val ctx: Context) {

    private val pref = ctx.getSharedPreferences("autodroid_policy", Context.MODE_PRIVATE)

    /** 本次会话开始时间 */
    private var sessionStart = System.currentTimeMillis()

    /** 记录本次任务已完成的会话轮数，用于日志 */
    var breakCount = 0
        private set

    // ---------- 时段 ----------

    /** 当前是否在允许的运行时段内 */
    fun inTimeWindow(cfg: TaskConfig): Boolean {
        if (!cfg.respectTimeWindow) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (cfg.hourFrom <= cfg.hourTo) {
            h in cfg.hourFrom until cfg.hourTo
        } else {
            // 跨零点，如 22 → 6
            h >= cfg.hourFrom || h < cfg.hourTo
        }
    }

    /** 距离时段开放还有多少毫秒（在时段内返回 0） */
    fun msUntilWindowOpen(cfg: TaskConfig): Long {
        if (inTimeWindow(cfg)) return 0L
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, cfg.hourFrom)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis - now.timeInMillis
    }

    // ---------- 会话休息 ----------

    /** 本次会话是否已经跑够时长，需要休息 */
    fun needBreak(cfg: TaskConfig): Boolean {
        if (cfg.sessionMinutes <= 0) return false
        val elapsed = System.currentTimeMillis() - sessionStart
        return elapsed >= cfg.sessionMinutes * 60_000L
    }

    /** 重置会话计时（休息结束后调用） */
    fun resetSession() {
        sessionStart = System.currentTimeMillis()
        breakCount++
    }

    /** 本次会话已运行秒数 */
    fun sessionElapsedSec(): Long = (System.currentTimeMillis() - sessionStart) / 1000

    // ---------- 单日配额 ----------

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())

    private fun keyDaily(kind: String) = "daily_${kind}_${today()}"

    fun todayLikes(): Int = pref.getInt(keyDaily("like"), 0)

    fun todayComments(): Int = pref.getInt(keyDaily("comment"), 0)

    fun addLike() = pref.edit().putInt(keyDaily("like"), todayLikes() + 1).apply()

    fun addComment() = pref.edit().putInt(keyDaily("comment"), todayComments() + 1).apply()

    /** 点赞配额是否已用完 */
    fun likeQuotaExhausted(cfg: TaskConfig): Boolean =
        cfg.dailyLikeLimit > 0 && todayLikes() >= cfg.dailyLikeLimit

    /** 评论配额是否已用完 */
    fun commentQuotaExhausted(cfg: TaskConfig): Boolean =
        cfg.dailyCommentLimit > 0 && todayComments() >= cfg.dailyCommentLimit

    fun quotaSummary(cfg: TaskConfig): String {
        val l = if (cfg.dailyLikeLimit > 0) "${todayLikes()}/${cfg.dailyLikeLimit}" else "${todayLikes()}/∞"
        val c =
            if (cfg.dailyCommentLimit > 0) "${todayComments()}/${cfg.dailyCommentLimit}" else "${todayComments()}/∞"
        return "今日已用：点赞 $l，评论 $c"
    }

    /** 重置今日配额（调试用） */
    fun resetToday() {
        pref.edit().remove(keyDaily("like")).remove(keyDaily("comment")).apply()
    }

    // ---------- 评论去重 ----------

    /**
     * 挑一条还没用过的评论。
     *
     * 池子用尽时不能简单地 clear 后随机取——那样可能出现"刚发完 A 又发 A"。
     * 这里用 lastPicked 记录上一条，重新开始时从池子里排除它，保证相邻两条不重复。
     */
    fun pickComment(
        pool: List<String>,
        used: MutableSet<String>,
        unique: Boolean,
        lastPicked: String? = null
    ): String? {
        if (pool.isEmpty()) return null
        if (!unique) return Humanizer.pick(pool)

        val fresh = pool.filter { it !in used }
        if (fresh.isNotEmpty()) return Humanizer.pick(fresh)

        // 一轮用完：重新开始，但避开上一条，避免相邻重复
        used.clear()
        val candidates = if (pool.size > 1 && lastPicked != null) pool.filter { it != lastPicked } else pool
        return Humanizer.pick(candidates)
    }

    /**
     * 给评论加点自然变化，降低完全重复的概率。
     *
     * 两个约束：
     *  1. 总长度受限（多数平台评论上限 100~150 字），超长会被截断或直接发送失败
     *  2. 不在已有标点后重复加同类标点，避免出现"～～""。。"这种一眼假的组合
     */
    fun naturalize(text: String, maxLen: Int = 100): String {
        if (text.isEmpty()) return text
        var s = text

        // 偶尔加个前缀（前缀不影响结尾标点判断，先处理）
        if (Humanizer.chance(0.12) && !s.startsWith("确实") && !s.startsWith("真的")) {
            s = (Humanizer.pick(listOf("确实，", "真的，", "哇，", "哈哈，", "嗯，")) ?: "") + s
        }

        // 随机加个尾巴语气词，但避免和已有结尾重复
        if (Humanizer.chance(0.25)) {
            val tail = Humanizer.pick(TAILS) ?: ""
            if (!s.endsWith(tail) && !(tail.length == 1 && s.lastOrNull() == tail.firstOrNull())) {
                s += tail
            }
        }

        // 硬截断，避免超出平台上限
        if (s.length > maxLen) s = s.substring(0, maxLen)
        return s
    }

    private val TAILS = listOf("～", "~", "！", "。", "哈哈", "😄", "❤️")
}
