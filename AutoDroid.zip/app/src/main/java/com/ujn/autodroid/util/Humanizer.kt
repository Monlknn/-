package com.ujn.autodroid.util

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * 拟人化采样工具。
 *
 * 核心思路：真人操作在统计上不是"均匀随机"，而是有明显形状的分布——
 *   · 操作间隔：对数正态分布（大量集中在 1~3s，带长尾，偶尔发呆十几秒）
 *   · 点击落点：二维高斯分布（集中在控件中心附近，极少点边缘）
 *   · 滑动轨迹：带横向偏移的贝塞尔曲线 + 变化的时长
 * 用均匀分布去模拟，反而比固定值更容易被识别，因为"太平坦"本身就是特征。
 */
object Humanizer {

    private val rnd = Random(System.nanoTime())

    // ---------- 基础分布 ----------

    /** Box-Muller 标准正态采样 */
    private fun gaussian(): Double {
        var u: Double
        var v: Double
        var s: Double
        do {
            u = rnd.nextDouble() * 2.0 - 1.0
            v = rnd.nextDouble() * 2.0 - 1.0
            s = u * u + v * v
        } while (s >= 1.0 || s == 0.0)
        return u * sqrt(-2.0 * ln(s) / s)
    }

    /**
     * 对数正态采样，返回毫秒。
     * @param medianMs 中位数（最常见的间隔时长）
     * @param sigma 形状参数，越大长尾越明显。0.55 左右比较接近真人
     */
    fun logNormalMs(medianMs: Long, sigma: Double = 0.55): Long {
        if (medianMs <= 0) return 0L
        val mu = ln(medianMs.toDouble())
        val v = exp(mu + sigma * gaussian())
        // 截断到 [0.2x, 6x] 中位数，避免极端值把流程拖死
        return v.coerceIn(medianMs * 0.2, medianMs * 6.0).toLong()
    }

    /** 在区间内均匀取一次（用于纯随机的选择，不用于时间） */
    fun between(min: Long, max: Long): Long {
        if (max <= min) return min
        return rnd.nextLong(min, max)
    }

    fun betweenInt(min: Int, max: Int): Int {
        if (max <= min) return min
        return rnd.nextInt(min, max)
    }

    /** 在区间内取一个 Double（用于比例、阈值等非时间参数） */
    fun betweenDouble(min: Double, max: Double): Double {
        if (max <= min) return min
        return min + rnd.nextDouble() * (max - min)
    }

    /** 按概率返回 true */
    fun chance(p: Double): Boolean = rnd.nextDouble() < p.coerceIn(0.0, 1.0)

    /** 从列表随机取一个，空列表返回 null */
    fun <T> pick(list: List<T>): T? = if (list.isEmpty()) null else list[rnd.nextInt(list.size)]

    // ---------- 点击落点 ----------

    /**
     * 在控件矩形内按二维高斯采样一个落点。
     * 不会永远点正中心（这是最明显的机器特征），同时避开边缘区域。
     *
     * @param left/top/right/bottom 控件屏幕坐标
     * @param sigmaRatio 标准差占控件尺寸的比例
     */
    fun jitteredPoint(
        left: Int, top: Int, right: Int, bottom: Int,
        sigmaRatio: Double = 0.12
    ): Pair<Int, Int> {
        val w = (right - left).coerceAtLeast(1)
        val h = (bottom - top).coerceAtLeast(1)
        val cx = left + w / 2.0
        val cy = top + h / 2.0
        val sigmaX = w * sigmaRatio
        val sigmaY = h * sigmaRatio

        // 高斯偏移，限制在内切矩形内（留 12% 边距，避免点到控件外）
        val maxDx = w * 0.38
        val maxDy = h * 0.38
        val dx = (gaussian() * sigmaX).coerceIn(-maxDx, maxDx)
        val dy = (gaussian() * sigmaY).coerceIn(-maxDy, maxDy)
        return Pair((cx + dx).toInt(), (cy + dy).toInt())
    }

    // ---------- 滑动轨迹 ----------

    /**
     * 一条拟人化滑动的完整描述。
     * 用具名数据类而不是 Triple，是因为三个 Long 靠位置区分太容易传错。
     */
    data class SwipePlan(
        /** 路径点序列（屏幕坐标） */
        val points: List<Pair<Float, Float>>,
        /** 手势持续时长(ms) */
        val durationMs: Long,
        /** 手指离开屏幕后的自然停顿(ms) */
        val settleMs: Long
    )

    /**
     * 生成一条拟人化的滑动路径（二次贝塞尔 + 轻微抖动）。
     * 真人滑动不是直线：手会有横向偏移，起止点也不固定。
     */
    fun swipePath(
        startX: Float, startY: Float, endX: Float, endY: Float
    ): SwipePlan {
        // 控制点：在中点基础上横向偏移，制造弧度
        val midX = (startX + endX) / 2f
        val midY = (startY + endY) / 2f
        val lateral = (rnd.nextDouble() * 2 - 1) * 90.0    // ±90px 横向偏移
        val ctrlX = midX + lateral.toFloat()
        val ctrlY = midY + (rnd.nextDouble() * 40 - 20).toFloat()

        val steps = betweenInt(8, 16)
        val pts = ArrayList<Pair<Float, Float>>(steps + 1)
        for (i in 0..steps) {
            val t = i.toDouble() / steps
            // 二次贝塞尔
            val x = (1 - t) * (1 - t) * startX + 2 * (1 - t) * t * ctrlX + t * t * endX
            val y = (1 - t) * (1 - t) * startY + 2 * (1 - t) * t * ctrlY + t * t * endY
            // 叠加微小抖动，模拟手指不稳
            val jx = (gaussian() * 1.8).toFloat()
            val jy = (gaussian() * 1.8).toFloat()
            pts.add(Pair((x + jx).toFloat(), (y + jy).toFloat()))
        }
        return SwipePlan(
            points = pts,
            durationMs = between(280L, 520L),
            settleMs = between(80L, 260L)
        )
    }

    /** 正弦缓动，让轨迹速度更接近真人（快-慢-快） */
    fun easeInOut(t: Double): Double = 0.5 * (1 - cos(PI * t))

    // ---------- 文本输入节奏 ----------

    /**
     * 把一段文字切成"逐字输入"的批次。
     * 真人打字有节奏，偶尔停顿、偶尔手快连打两个字符。
     */
    fun typingBatches(text: String): List<Pair<String, Long>> {
        if (text.isEmpty()) return emptyList()
        val out = ArrayList<Pair<String, Long>>()
        var i = 0
        while (i < text.length) {
            // 大多数情况一次一个字，偶尔连打两个
            val take = if (rnd.nextDouble() < 0.18 && i + 2 <= text.length) 2 else 1
            val chunk = text.substring(i, minOf(i + take, text.length))
            // 打每个字的间隔：中位数 140ms
            var delay = logNormalMs(140L, 0.5)
            // 5% 概率"卡顿"一下，慢一拍
            if (rnd.nextDouble() < 0.05) delay += between(300L, 900L)
            out.add(Pair(chunk, delay))
            i += take
        }
        return out
    }
}
