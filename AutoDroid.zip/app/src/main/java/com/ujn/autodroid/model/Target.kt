package com.ujn.autodroid.model

import org.json.JSONObject

/**
 * 控件定位方式。
 * - ID：按 viewIdResourceName 匹配，支持写全名(com.xx:id/abc)或只写 abc
 * - TEXT：按控件 text 匹配
 * - DESC：按控件 contentDescription 匹配（短视频 App 的图标按钮一般只有 desc）
 */
enum class MatchMode(val key: String) {
    ID("id"),
    TEXT("text"),
    DESC("desc");

    companion object {
        fun fromKey(key: String?): MatchMode =
            values().firstOrNull { it.key == key } ?: DESC
    }
}

/**
 * 一个"控件定位规则"。
 * values 是候选列表，任意一个命中即算找到，用来兼容不同 App 版本 / 不同文案。
 */
data class Target(
    val mode: MatchMode = MatchMode.DESC,
    val values: List<String> = emptyList(),
    val contains: Boolean = true,   // true=包含匹配，false=完全一致
    val index: Int = 0              // 命中多个时取第几个
) {
    fun isEmpty(): Boolean = values.isEmpty()

    fun toJson(): JSONObject = JSONObject().apply {
        put("mode", mode.key)
        put("values", org.json.JSONArray().apply { values.forEach { put(it) } })
        put("contains", contains)
        put("index", index)
    }

    companion object {
        fun fromJson(o: JSONObject?): Target? {
            if (o == null) return null
            val arr = o.optJSONArray("values") ?: return null
            val list = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val s = arr.optString(i, "")
                if (s.isNotBlank()) list.add(s)
            }
            if (list.isEmpty()) return null
            return Target(
                mode = MatchMode.fromKey(o.optString("mode")),
                values = list,
                contains = o.optBoolean("contains", true),
                index = o.optInt("index", 0)
            )
        }

        /** 便捷构造：desc("点赞", "赞") */
        fun desc(vararg v: String, contains: Boolean = true, index: Int = 0) =
            Target(MatchMode.DESC, v.toList(), contains, index)

        fun text(vararg v: String, contains: Boolean = true, index: Int = 0) =
            Target(MatchMode.TEXT, v.toList(), contains, index)

        fun id(vararg v: String, index: Int = 0) =
            Target(MatchMode.ID, v.toList(), false, index)
    }
}
