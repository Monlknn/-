package com.ujn.autodroid.store

import android.content.Context
import com.ujn.autodroid.model.AppProfile
import com.ujn.autodroid.model.TaskConfig
import org.json.JSONArray
import org.json.JSONObject

/** 配置持久化：SharedPreferences + org.json（不引入任何三方序列化库） */
object ConfigStore {

    private const val PREF = "autodroid"
    private const val KEY_TASK = "task"
    private const val KEY_CUSTOM = "custom_profiles"

    fun saveTask(ctx: Context, cfg: TaskConfig) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_TASK, cfg.toJson().toString()).apply()
    }

    fun loadTask(ctx: Context): TaskConfig {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_TASK, null)
            ?: return TaskConfig()
        return try {
            TaskConfig.fromJson(JSONObject(s))
        } catch (e: Exception) {
            TaskConfig()
        }
    }

    fun saveCustom(ctx: Context, list: List<AppProfile>) {
        val arr = JSONArray()
        list.filter { !it.builtIn }.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }

    fun loadCustom(ctx: Context): List<AppProfile> {
        val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_CUSTOM, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            val out = ArrayList<AppProfile>()
            for (i in 0 until arr.length()) out.add(AppProfile.fromJson(arr.getJSONObject(i)))
            out
        } catch (e: Exception) {
            emptyList()
        }
    }
}
