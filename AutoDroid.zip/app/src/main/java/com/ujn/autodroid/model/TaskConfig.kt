package com.ujn.autodroid.model

import org.json.JSONObject

/**
 * 一次自动化任务的参数。
 *
 * P0/P1/P2 三档风控缓解参数都在这里：
 *  · P0 引擎层：延时中位数、坐标抖动、轨迹随机（由 Humanizer 参数控制，这里只暴露中位数）
 *  · P1 行为层：动作顺序随机、跳过概率、观看停留、逐字输入
 *  · P2 策略层：运行时段、会话休息、单日配额、评论池
 */
data class TaskConfig(
    var profileId: String = "douyin",
    /** 目标 App 包名（默认跟随模板，可手动覆盖） */
    var pkg: String = "",
    /** 搜索关键词，一行一个 */
    var keywords: List<String> = listOf("风景"),
    var doLike: Boolean = true,
    var doComment: Boolean = false,
    /** 评论内容，一行一条，随机抽取；支持 {keyword} 占位符 */
    var comments: List<String> = listOf("拍得真好，学习了"),
    /** 每个关键词处理多少个视频 */
    var videosPerKeyword: Int = 3,
    /** 关键词循环多少轮 */
    var loopCount: Int = 1,

    // ---------- P0：节奏 ----------
    /** 操作间隔的中位数（毫秒）。实际延时按对数正态分布采样，围绕这个值波动 */
    var delayMedianMs: Long = 2200L,
    /** 对数正态形状参数，越大长尾越长（越像真人发呆） */
    var delaySigma: Double = 0.55,

    // ---------- P1：行为随机化 ----------
    /** 进入视频后先"看"一会儿再操作，单位毫秒 */
    var watchMinMs: Long = 3000L,
    var watchMaxMs: Long = 12000L,
    /** 完全不操作的视频比例（直接划走） */
    var skipVideoProb: Double = 0.12,
    /** 只点赞不评论（在都勾选的情况下）的比例 */
    var onlyLikeProb: Double = 0.35,
    /** 只评论不点赞的比例 */
    var onlyCommentProb: Double = 0.10,
    /** 搜索词是否逐字输入（更慢但更像人；关闭则一次性粘贴） */
    var typeCharByChar: Boolean = true,

    // ---------- P2：策略 ----------
    /** 每天允许运行的起始/结束小时（0-23，跨零点如 22→6 也支持） */
    var hourFrom: Int = 8,
    var hourTo: Int = 23,
    /** 是否遵守运行时段 */
    var respectTimeWindow: Boolean = false,
    /** 连续运行的会话时长（分钟），到点休息 */
    var sessionMinutes: Int = 25,
    /** 会话之间的休息时长（分钟） */
    var breakMinutes: Int = 8,
    /** 单日点赞上限（0=不限制） */
    var dailyLikeLimit: Int = 50,
    /** 单日评论上限（0=不限制） */
    var dailyCommentLimit: Int = 10,
    /** 评论内容是否强制不重复 */
    var uniqueComment: Boolean = true,

    /** 检测到已点赞就跳过，防止把赞取消掉 */
    var skipIfLiked: Boolean = true,
    /** 连续失败多少次放弃当前关键词 */
    var maxFail: Int = 3,
    /** 试运行：只走流程、打日志，不真的点击点赞/发送 */
    var dryRun: Boolean = false
) {
    val delayMinMs: Long get() = (delayMedianMs * 0.2).toLong()

    fun toJson(): JSONObject = JSONObject().apply {
        put("profileId", profileId)
        put("pkg", pkg)
        put("keywords", org.json.JSONArray().apply { keywords.forEach { put(it) } })
        put("doLike", doLike)
        put("doComment", doComment)
        put("comments", org.json.JSONArray().apply { comments.forEach { put(it) } })
        put("videosPerKeyword", videosPerKeyword)
        put("loopCount", loopCount)
        put("delayMedianMs", delayMedianMs)
        put("delaySigma", delaySigma)
        put("watchMinMs", watchMinMs)
        put("watchMaxMs", watchMaxMs)
        put("skipVideoProb", skipVideoProb)
        put("onlyLikeProb", onlyLikeProb)
        put("onlyCommentProb", onlyCommentProb)
        put("typeCharByChar", typeCharByChar)
        put("hourFrom", hourFrom)
        put("hourTo", hourTo)
        put("respectTimeWindow", respectTimeWindow)
        put("sessionMinutes", sessionMinutes)
        put("breakMinutes", breakMinutes)
        put("dailyLikeLimit", dailyLikeLimit)
        put("dailyCommentLimit", dailyCommentLimit)
        put("uniqueComment", uniqueComment)
        put("skipIfLiked", skipIfLiked)
        put("maxFail", maxFail)
        put("dryRun", dryRun)
    }

    companion object {
        fun fromJson(o: JSONObject): TaskConfig {
            fun arr(key: String, def: List<String>): List<String> {
                val a = o.optJSONArray(key) ?: return def
                val l = ArrayList<String>()
                for (i in 0 until a.length()) {
                    val s = a.optString(i, "").trim()
                    if (s.isNotEmpty()) l.add(s)
                }
                return if (l.isEmpty()) def else l
            }
            return TaskConfig(
                profileId = o.optString("profileId", "douyin"),
                pkg = o.optString("pkg", ""),
                keywords = arr("keywords", listOf("风景")),
                doLike = o.optBoolean("doLike", true),
                doComment = o.optBoolean("doComment", false),
                comments = arr("comments", listOf("拍得真好，学习了")),
                videosPerKeyword = o.optInt("videosPerKeyword", 3),
                loopCount = o.optInt("loopCount", 1),
                delayMedianMs = o.optLong("delayMedianMs", 2200L),
                delaySigma = o.optDouble("delaySigma", 0.55),
                watchMinMs = o.optLong("watchMinMs", 3000L),
                watchMaxMs = o.optLong("watchMaxMs", 12000L),
                skipVideoProb = o.optDouble("skipVideoProb", 0.12),
                onlyLikeProb = o.optDouble("onlyLikeProb", 0.35),
                onlyCommentProb = o.optDouble("onlyCommentProb", 0.10),
                typeCharByChar = o.optBoolean("typeCharByChar", true),
                hourFrom = o.optInt("hourFrom", 8),
                hourTo = o.optInt("hourTo", 23),
                respectTimeWindow = o.optBoolean("respectTimeWindow", false),
                sessionMinutes = o.optInt("sessionMinutes", 25),
                breakMinutes = o.optInt("breakMinutes", 8),
                dailyLikeLimit = o.optInt("dailyLikeLimit", 50),
                dailyCommentLimit = o.optInt("dailyCommentLimit", 10),
                uniqueComment = o.optBoolean("uniqueComment", true),
                skipIfLiked = o.optBoolean("skipIfLiked", true),
                maxFail = o.optInt("maxFail", 3),
                dryRun = o.optBoolean("dryRun", false)
            )
        }
    }
}
