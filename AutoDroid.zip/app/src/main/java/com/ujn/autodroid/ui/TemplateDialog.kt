package com.ujn.autodroid.ui

import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.ujn.autodroid.model.AppProfile
import com.ujn.autodroid.model.Target

/**
 * 自定义 App 模板：把关键控件的候选词填进去即可，多个候选用英文逗号分隔。
 * 留空的字段会在运行时自动降级（比如输入框留空就自动找当前页面可编辑的控件）。
 */
object TemplateDialog {

    fun show(ctx: Context, onSave: (AppProfile) -> Unit) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
        }

        fun field(hint: String, def: String = ""): EditText = EditText(ctx).apply {
            this.hint = hint
            setText(def)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setSingleLine(false)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val etName = field("模板名称，如：抖音 v28")
        val etPkg = field("App 包名，如：com.ss.android.ugc.aweme")
        val etSearchEntry = field("搜索入口按钮（desc 候选，逗号分隔）", "搜索,搜索，按钮")
        val etSearchBox = field("搜索输入框（id 候选，逗号分隔，可留空）", "")
        val etSearchGo = field("搜索按钮（text 候选，可留空=用输入法回车）", "搜索,搜索一下")
        val etResultTab = field("结果页\"视频\"tab（text 候选，可留空）", "视频,作品")
        val etLike = field("点赞按钮（desc 候选，逗号分隔）", "点赞,赞,喜欢")
        val etCommentEntry = field("评论入口按钮（desc 候选，逗号分隔）", "评论,评论，按钮")
        val etCommentBox = field("评论输入框（id 候选，可留空）", "")
        val etSend = field("发送按钮（text 候选，逗号分隔）", "发送,发布")
        val etBackHome = field("返回首页需按几次返回键（默认 3）", "3")

        listOf(
            etName, etPkg, etSearchEntry, etSearchBox, etSearchGo, etResultTab,
            etLike, etCommentEntry, etCommentBox, etSend, etBackHome
        ).forEach { root.addView(it) }

        val scroll = ScrollView(ctx).apply { addView(root) }

        // 用一个可拦截的 builder，保证校验不通过时不关闭对话框（原来的用法会静默失败）
        val builder = AlertDialog.Builder(ctx)
            .setTitle("新建自定义模板")
            .setView(scroll)
            .setNegativeButton("取消", null)

        val dialog = builder.setPositiveButton("保存", null).create()

        fun split(s: String): List<String> =
            s.split(",", "，").map { it.trim() }.filter { it.isNotEmpty() }

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pkg = etPkg.text.toString().trim()
                if (pkg.isBlank()) {
                    etPkg.error = "请填写 App 包名"
                    Toast.makeText(ctx, "包名不能为空", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!pkg.matches(Regex("[A-Za-z0-9_.]+"))) {
                    etPkg.error = "包名只能包含字母、数字、下划线和点"
                    return@setOnClickListener
                }

                val name = etName.text.toString().trim().ifBlank { pkg }

                val profile = AppProfile(
                    id = "custom_$pkg",
                    name = name,
                    pkg = pkg,
                    searchEntry = split(etSearchEntry.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.desc(*it.toTypedArray()) },
                    searchBox = split(etSearchBox.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { v -> Target.id(*v.toTypedArray()) },
                    searchGo = split(etSearchGo.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.text(*it.toTypedArray()) },
                    resultTab = split(etResultTab.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.text(*it.toTypedArray()) },
                    like = split(etLike.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.desc(*it.toTypedArray()) },
                    commentEntry = split(etCommentEntry.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.desc(*it.toTypedArray()) },
                    commentBox = split(etCommentBox.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { v -> Target.id(*v.toTypedArray()) },
                    commentSend = split(etSend.text.toString())
                        .takeIf { it.isNotEmpty() }?.let { Target.text(*it.toTypedArray()) },
                    backToHome = etBackHome.text.toString().toIntOrNull()?.coerceIn(1, 10) ?: 3,
                    builtIn = false
                )
                onSave(profile)
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
