package com.ujn.autodroid.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import com.ujn.autodroid.model.MatchMode
import com.ujn.autodroid.model.Target
import com.ujn.autodroid.util.Humanizer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** 控件树的一个节点快照，用于"探测控件"功能 */
data class DumpNode(
    val id: String,
    val text: String,
    val desc: String,
    val cls: String,
    val clickable: Boolean,
    val editable: Boolean,
    val bounds: Rect
)

/**
 * 控件查找与操作。
 * 所有操作都带"轮询等待"，因为 App 页面加载有延迟，单纯 find 一次基本必失败。
 */
object NodeFinder {

    private const val MAX_WALK = 1200

    /**
     * 轮询等待直到出现目标控件，返回该规则命中的所有节点（已按树序排列）。
     * 返回的节点是**新引用**，调用方必须 recycle。
     */
    fun waitFor(
        service: AccessibilityService,
        t: Target,
        timeoutMs: Long,
        stepMs: Long = 300L
    ): List<AccessibilityNodeInfo> {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            val found = search(service, t)
            if (found.isNotEmpty()) return found
            SystemClock.sleep(stepMs)
        }
        return emptyList()
    }

    /**
     * 只查一次，不等待。
     * 返回的节点是**新引用**，调用方必须 recycle。
     */
    fun findOnce(service: AccessibilityService, t: Target): List<AccessibilityNodeInfo> =
        search(service, t)

    /** 等待任意一个目标出现，返回最先命中的那个。返回的是**新引用**，调用方必须 recycle */
    fun waitAny(
        service: AccessibilityService,
        targets: List<Target>,
        timeoutMs: Long
    ): AccessibilityNodeInfo? {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            targets.forEach { t ->
                val l = search(service, t)
                if (l.isNotEmpty()) {
                    // 只保留第一个，其余必须回收，否则每次轮询都会漏一堆节点
                    val first = l[0]
                    for (i in 1 until l.size) runCatching { l[i].recycle() }
                    return first
                }
            }
            SystemClock.sleep(300L)
        }
        return null
    }

    private fun search(service: AccessibilityService, t: Target): List<AccessibilityNodeInfo> {
        val root = service.rootInActiveWindow ?: return emptyList()
        val out = ArrayList<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(AccessibilityNodeInfo.obtain(root))
        var walked = 0
        try {
            while (queue.isNotEmpty() && walked < MAX_WALK) {
                val n = queue.removeFirst()
                walked++
                try {
                    if (out.size < 40 && matches(n, t)) {
                        out.add(AccessibilityNodeInfo.obtain(n))
                    }
                    for (i in 0 until n.childCount) {
                        val c = n.getChild(i)
                        if (c != null) queue.addLast(c)
                    }
                } finally {
                    n.recycle()
                }
            }
        } finally {
            while (queue.isNotEmpty()) {
                runCatching { queue.removeFirst().recycle() }
            }
        }
        return out
    }

    private fun matches(n: AccessibilityNodeInfo, t: Target): Boolean {
        val cand = when (t.mode) {
            MatchMode.ID -> n.viewIdResourceName ?: ""
            MatchMode.TEXT -> n.text?.toString() ?: ""
            MatchMode.DESC -> n.contentDescription?.toString() ?: ""
        }
        if (cand.isBlank()) return false
        for (v in t.values) {
            if (v.isBlank()) continue
            val hit = if (t.mode == MatchMode.ID) idHit(cand, v)
            else if (t.contains) cand.contains(v, ignoreCase = true)
            else cand.equals(v, ignoreCase = true)
            if (hit) return true
        }
        return false
    }

    /** id 支持写全名(com.pkg:id/xxx)或只写 xxx */
    private fun idHit(full: String, v: String): Boolean {
        if (full == v) return true
        if (!v.contains(":id/")) {
            val tail = full.substringAfterLast('/')
            if (tail == v) return true
        }
        return false
    }

    /** 找可编辑的输入框（模板没配输入框时的兜底） */
    fun findEditable(service: AccessibilityService): AccessibilityNodeInfo? {
        val root = service.rootInActiveWindow ?: return null
        var result: AccessibilityNodeInfo? = null
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(AccessibilityNodeInfo.obtain(root))
        var walked = 0
        try {
            while (queue.isNotEmpty() && walked < MAX_WALK && result == null) {
                val n = queue.removeFirst()
                walked++
                try {
                    if (n.isEditable && n.isEnabled && n.isVisibleToUser) {
                        result = AccessibilityNodeInfo.obtain(n)
                    } else {
                        for (i in 0 until n.childCount) {
                            val c = n.getChild(i)
                            if (c != null) queue.addLast(c)
                        }
                    }
                } finally {
                    n.recycle()
                }
            }
        } finally {
            while (queue.isNotEmpty()) runCatching { queue.removeFirst().recycle() }
        }
        return result
    }

    /**
     * 向上回溯找到真正可点击的祖先（很多 App 的图标本身不可点击，父布局才可点击）。
     *
     * 所有权约定：返回的节点如果**不是**传入的那个，说明是新取到的引用，
     * 调用方用完后必须 recycle，否则会漏回收（见 releaseAncestor）。
     */
    private fun clickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var cur = node
        var p = cur.parent
        var depth = 0
        while (p != null && depth < 6) {
            if (p.isClickable && p.isEnabled) return p
            val next = p.parent
            // 如果这一级不是我们要的，且它本身是新引用，立刻回收，避免链路漏回收
            if (p !== node) runCatching { p.recycle() }
            cur = p
            p = next
            depth++
        }
        return node
    }

    /** 回收 clickableAncestor 可能新取到的节点（传回原节点则不做任何事） */
    fun releaseAncestor(original: AccessibilityNodeInfo, ancestor: AccessibilityNodeInfo) {
        if (ancestor !== original) runCatching { ancestor.recycle() }
    }

    /** 点击：优先 ACTION_CLICK；需要走手势时用高斯抖动落点，避免永远点正中心 */
    fun click(service: AccessibilityService, node: AccessibilityNodeInfo): Boolean {
        val target = if (node.isClickable) node else clickableAncestor(node)
        var ok = false
        try {
            ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (!ok) ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (!ok) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty) {
                    val (x, y) = Humanizer.jitteredPoint(rect.left, rect.top, rect.right, rect.bottom)
                    ok = tap(service, x, y)
                }
            }
        } finally {
            // 只有 target 是新取到的引用才回收
            releaseAncestor(node, target)
        }
        return ok
    }

    /**
     * 输入文本：ACTION_SET_TEXT 为主，剪贴板粘贴兜底。
     * 剪贴板是用户共享资源，粘贴完会尽量恢复原内容，避免污染用户的剪贴板。
     */
    fun inputText(service: AccessibilityService, node: AccessibilityNodeInfo, text: String): Boolean {
        runCatching { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
        SystemClock.sleep(150)
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            text
        )
        if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true

        return runCatching {
            val cm = service.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            // 备份原剪贴板
            val backup = runCatching {
                if (cm.hasPrimaryClip()) {
                    cm.primaryClip?.getItemAt(0)?.coerceToText(service)?.toString()
                } else null
            }.getOrNull()

            cm.setPrimaryClip(ClipData.newPlainText("autodroid", text))
            SystemClock.sleep(120)
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)

            // 恢复原剪贴板内容
            if (backup != null) {
                runCatching { cm.setPrimaryClip(ClipData.newPlainText("restore", backup)) }
            } else {
                runCatching {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) cm.clearPrimaryClip()
                }
            }
            ok
        }.getOrDefault(false)
    }

    fun tap(service: AccessibilityService, x: Int, y: Int): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatch(service, path, 50L)
    }

    // ---------- 文本编辑 ----------

    /** 直接设置文本（一次性写入） */
    fun setText(service: AccessibilityService, node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** 逐字追加场景下用的"设置到当前全量文本"，与 setText 等价但语义清晰 */
    fun appendText(service: AccessibilityService, node: AccessibilityNodeInfo, full: String): Boolean =
        setText(service, node, full)

    /** 清空输入框内容 */
    fun clearText(service: AccessibilityService, node: AccessibilityNodeInfo): Boolean {
        if (setText(service, node, "")) return true
        return runCatching {
            val args = Bundle().apply {
                putInt(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0
                )
                putInt(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT,
                    (node.text?.length ?: 0)
                )
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
            node.performAction(AccessibilityNodeInfo.ACTION_CUT)
        }.getOrDefault(false)
    }

    /** 上滑翻页（切下一个视频）：贝塞尔曲线 + 变化的时长与起止点 */
    fun swipeUp(service: AccessibilityService, w: Int, h: Int): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        // 起点和终点都加随机偏移，真人不会每次都划同样的距离
        val startX = w * (0.42f + Humanizer.betweenDouble(0.0, 0.16)).toFloat()
        val startY = h * (0.72f + Humanizer.betweenDouble(0.0, 0.12)).toFloat()
        val endY = h * (0.20f + Humanizer.betweenDouble(0.0, 0.14)).toFloat()

        val plan = Humanizer.swipePath(startX, startY, startX, endY)
        val path = Path()
        plan.points.forEachIndexed { i, p ->
            if (i == 0) path.moveTo(p.first, p.second) else path.lineTo(p.first, p.second)
        }
        val ok = dispatch(service, path, plan.durationMs)
        // 手指离开屏幕后的自然停顿
        SystemClock.sleep(plan.settleMs)
        return ok
    }

    private fun dispatch(service: AccessibilityService, path: Path, durationMs: Long): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val latch = CountDownLatch(1)
        var ok = false
        val res = service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                ok = false
                latch.countDown()
            }
        }, null)
        if (!res) return false
        latch.await(durationMs + 2000L, TimeUnit.MILLISECONDS)
        return ok
    }

    /** 读取节点的文案特征（用于判断是否已点赞） */
    fun signature(node: AccessibilityNodeInfo): String {
        val t = node.text?.toString().orEmpty()
        val d = node.contentDescription?.toString().orEmpty()
        return "$t|$d"
    }

    /** dump 当前窗口控件树，给"探测控件"用 */
    fun dump(service: AccessibilityService, limit: Int = 200): List<DumpNode> {
        val root = service.rootInActiveWindow ?: return emptyList()
        val out = ArrayList<DumpNode>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(AccessibilityNodeInfo.obtain(root))
        var walked = 0
        try {
            while (queue.isNotEmpty() && walked < MAX_WALK && out.size < limit) {
                val n = queue.removeFirst()
                walked++
                try {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    val id = n.viewIdResourceName ?: ""
                    val text = n.text?.toString() ?: ""
                    val desc = n.contentDescription?.toString() ?: ""
                    val cls = n.className?.toString() ?: ""
                    if (id.isNotEmpty() || text.isNotEmpty() || desc.isNotEmpty() ||
                        n.isClickable || n.isEditable
                    ) {
                        out.add(
                            DumpNode(
                                id = id,
                                text = text.replace('\n', ' '),
                                desc = desc.replace('\n', ' '),
                                cls = cls.substringAfterLast('.'),
                                clickable = n.isClickable,
                                editable = n.isEditable,
                                bounds = r
                            )
                        )
                    }
                    for (i in 0 until n.childCount) {
                        val c = n.getChild(i)
                        if (c != null) queue.addLast(c)
                    }
                } finally {
                    n.recycle()
                }
            }
        } finally {
            while (queue.isNotEmpty()) runCatching { queue.removeFirst().recycle() }
        }
        return out
    }
}
