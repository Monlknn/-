package com.ujn.autodroid.service

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.ujn.autodroid.R
import com.ujn.autodroid.core.NodeFinder
import com.ujn.autodroid.core.TaskEngine
import com.ujn.autodroid.model.AppProfile
import com.ujn.autodroid.model.TaskConfig
import com.ujn.autodroid.util.LogBus

/**
 * 核心无障碍服务：负责前台保活、悬浮控制球、调度 TaskEngine。
 */
class AutoService : AccessibilityService() {

    companion object {
        private const val CHANNEL_ID = "autodroid"
        private const val NOTI_ID = 1001
        const val ACTION_STOP = "com.ujn.autodroid.ACTION_STOP"

        @Volatile
        var instance: AutoService? = null

        @Volatile
        var running = false

        /** UI 可在 onResume 时挂上，用于任务状态变化时刷新按钮 */
        var onStateChange: (() -> Unit)? = null

        /**
         * 判断无障碍服务是否已经开启。
         *
         * 注意：部分 ROM 在 ENABLED_ACCESSIBILITY_SERVICES 里写的是短名
         * （com.ujn.autodroid/.service.AutoService）甚至省略包名的形式，
         * 只比对全名会误报"未开启"。所以做了多形态匹配，
         * 并以服务实例是否存在作为最终兜底。
         */
        fun isEnabled(ctx: Context): Boolean {
            // 服务实例已连接，直接判定为已开启，最可靠
            if (instance != null) return true

            val enabled = runCatching {
                Settings.Secure.getString(
                    ctx.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                )
            }.getOrNull() ?: return false

            val cn = ComponentName(ctx, AutoService::class.java)
            val full = cn.flattenToString()
            val short = cn.flattenToShortString()
            val pkg = ctx.packageName
            val cls = AutoService::class.java.name      // com.ujn.autodroid.service.AutoService
            val clsShort = cls.substringAfterLast('.')  // AutoService

            return enabled.split(':').any { entry ->
                val e = entry.trim()
                when {
                    e.equals(full, true) -> true
                    e.equals(short, true) -> true
                    // com.ujn.autodroid/.service.AutoService
                    e.equals("$pkg/.${cls.substringAfter(pkg)}", true) -> true
                    else -> e.contains(pkg, true) && e.endsWith(clsShort, true)
                }
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var engine: TaskEngine? = null
    private var worker: Thread? = null
    private var overlay: LinearLayout? = null
    private var overlayStatus: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        createChannel()
        runCatching { startForeground(NOTI_ID, buildNotification("自动化服务已就绪")) }
        LogBus.log("无障碍服务已连接")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 引擎采用"轮询 + 等待控件"策略，不依赖事件驱动，这里只做轻量记录
    }

    override fun onInterrupt() {
        LogBus.log("无障碍服务被中断")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTask()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopTask()
        instance = null
        super.onDestroy()
    }

    private val stateLock = Any()

    fun startTask(cfg: TaskConfig, profile: AppProfile) {
        synchronized(stateLock) {
            if (running) {
                LogBus.log("任务正在运行，请先停止")
                return
            }
            running = true
        }
        val e = TaskEngine(this)
        engine = e
        worker = Thread {
            try {
                e.run(cfg, profile)
            } catch (t: Throwable) {
                // 兜底：工作线程里任何未捕获异常都不能让服务卡在"运行中"状态
                LogBus.log("!! 工作线程异常退出：${t.message}")
                onTaskFinished()
            }
        }.apply { isDaemon = true; start() }
        mainHandler.post {
            showOverlay()
            updateNotification("任务运行中…")
        }
        onStateChange?.invoke()
    }

    /**
     * 请求停止。
     * 注意：这里**不**立刻把 running 置为 false——引擎收到 stopped 标记后还要按节奏
     * 走完返回首页等收尾动作（可能几秒钟）。如果提前放行，用户马上点开始就会出现
     * 两个引擎同时操作控件的情况。真正的复位在 onTaskFinished 里做。
     */
    fun stopTask() {
        val e = engine
        if (e != null && !e.stopped) {
            e.stopped = true
            LogBus.log("收到停止指令，将在当前步骤结束后停下")
            mainHandler.post { updateNotification("正在停止…") }
            // 看门狗：万一收尾卡住，最多 15 秒后强制复位。
            // 这里必须比对 engine 身份——用户停止后若立刻开新任务，旧看门狗不能误杀新任务。
            mainHandler.postDelayed({
                if (engine === e && running && worker?.isAlive == true) {
                    LogBus.log("收尾超时，强制结束任务线程")
                    worker?.let { runCatching { it.interrupt() } }
                    onTaskFinished()
                }
            }, 15_000L)
        } else if (!running) {
            // 没有在跑的任务，直接复位 UI 状态
            onTaskFinished()
        }
    }

    fun onTaskFinished() {
        synchronized(stateLock) {
            running = false
            worker = null
            engine = null
        }
        mainHandler.post {
            hideOverlay()
            updateNotification("任务结束")
            onStateChange?.invoke()
        }
    }

    /** 探测当前界面控件，返回给 UI 显示 */
    fun dumpCurrent(limit: Int = 120): List<com.ujn.autodroid.core.DumpNode> =
        NodeFinder.dump(this, limit)

    // ---------- 通知 ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                val ch = NotificationChannel(
                    CHANNEL_ID, "自动化运行状态", NotificationManager.IMPORTANCE_LOW
                )
                mgr.createNotificationChannel(ch)
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, com.ujn.autodroid.ui.MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, AutoService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("AutoDroid")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .addAction(0, "停止", stopPi)
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            mgr.notify(NOTI_ID, buildNotification(text))
        }
    }

    fun setStatus(text: String) {
        overlayStatus?.text = text
    }

    // ---------- 悬浮控制球（TYPE_ACCESSIBILITY_OVERLAY，不需要悬浮窗权限） ----------

    private fun showOverlay() {
        if (overlay != null) return
        runCatching {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 12, 16, 12)
                setBackgroundColor(Color.parseColor("#CC000000"))
            }
            val status = TextView(this).apply {
                text = "运行中…"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            }
            val stop = Button(this).apply {
                text = "停止任务"
                setOnClickListener { stopTask() }
            }
            root.addView(status)
            root.addView(stop)
            overlayStatus = status

            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = 12
                y = 200
            }
            wm.addView(root, lp)
            overlay = root
        }
    }

    private fun hideOverlay() {
        runCatching {
            overlay?.let {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            }
        }
        overlay = null
        overlayStatus = null
    }
}
