package com.ujn.autodroid.util

import android.os.Handler
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 极简日志总线：UI 可以注册监听实时显示，同时落一份到 App 私有目录，方便导出排查。
 */
object LogBus {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<(String) -> Unit>()
    private val buffer = StringBuilder()
    private const val MAX = 8000

    /** 日志文件单文件上限，超过就截断保留后半段，避免长期运行把存储写满 */
    private const val MAX_FILE_BYTES = 512 * 1024L

    /** 距离上次检查文件大小已写入的行数，避免每行都做一次 stat */
    private var linesSinceSizCheck = 0

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.CHINA)

    fun addListener(l: (String) -> Unit) {
        mainHandler.post { if (l !in listeners) listeners.add(l) }
    }

    fun removeListener(l: (String) -> Unit) {
        mainHandler.post { listeners.remove(l) }
    }

    /**
     * 写一行日志。
     * 注意：这里不整体加锁——文件 IO 相对慢，持锁会让多个调用点互相阻塞。
     * 缓冲区用 synchronized 小块保护，文件写入单独加锁。
     */
    fun log(msg: String, file: File? = null): String {
        val line = "${timeFmt.format(Date())}  $msg"

        synchronized(buffer) {
            buffer.append(line).append('\n')
            if (buffer.length > MAX) buffer.delete(0, buffer.length - MAX)
        }

        mainHandler.post {
            // 拷一份快照再回调，避免回调里读写 buffer 引发并发问题
            listeners.toList().forEach { runCatching { it(line) } }
        }

        file?.let { appendToFile(it, line) }
        return line
    }

    private val fileLock = Any()

    private fun appendToFile(file: File, line: String) {
        synchronized(fileLock) {
            runCatching {
                // 每 200 行检查一次大小，避免频繁 stat
                if (linesSinceSizCheck++ >= 200) {
                    linesSinceSizCheck = 0
                    if (file.exists() && file.length() > MAX_FILE_BYTES) {
                        // 保留后半段
                        val keep = file.readText().takeLast((MAX_FILE_BYTES / 2).toInt())
                        file.writeText("── 日志超过上限，已截断 ──\n" + keep)
                    }
                }
                file.appendText(line + "\n")
            }
        }
    }

    fun snapshot(): String = synchronized(buffer) { buffer.toString() }

    fun clear() {
        synchronized(buffer) { buffer.setLength(0) }
    }
}
