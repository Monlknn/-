package com.ujn.autodroid.model

/**
 * 内置模板库。
 *
 * 重要：短视频 App 每个版本都会改控件 id / 文案，下面给的是"多候选 + 包含匹配"的兜底配置，
 * 大多数机型能直接用；如果你的版本变了，用 App 里的【探测控件】功能 dump 出真实控件信息，
 * 然后在"自定义模板"里改对应的候选词即可，不需要改代码。
 */
object Profiles {

    private val douyin = AppProfile(
        id = "douyin",
        name = "抖音",
        pkg = "com.ss.android.ugc.aweme",
        searchEntry = Target.desc("搜索", "搜索，按钮", "搜索按钮"),
        searchBox = Target.id("et_search_kw", "search_edit_text", "et_search"),
        searchGo = Target.text("搜索", "搜索一下"),
        resultTab = Target.text("视频", "作品"),
        firstResult = null,
        resultX = 0.5f,
        resultY = 0.32f,
        like = Target.desc("点赞", "赞", "喜欢", "未点赞"),
        likedHints = listOf("已赞", "已点赞", "取消赞", "取消点赞", "取消喜欢", "已喜欢"),
        commentEntry = Target.desc("评论", "评论，按钮"),
        commentBox = Target.id("et_comment", "edit_text", "comment_edit"),
        commentSend = Target.text("发送", "发布"),
        afterCommentBack = 2,
        launchWaitMs = 4500L,
        stepWaitMs = 1200L,
        backToHome = 3,
        builtIn = true
    )

    private val kuaishou = AppProfile(
        id = "kuaishou",
        name = "快手",
        pkg = "com.smile.gifmaker",
        searchEntry = Target.desc("搜索", "搜索，按钮"),
        searchBox = Target.id("search_edit_text", "edit_text", "et_search"),
        searchGo = Target.text("搜索"),
        resultTab = Target.text("视频", "作品"),
        firstResult = null,
        resultX = 0.5f,
        resultY = 0.32f,
        like = Target.desc("点赞", "赞", "喜欢", "未点赞"),
        likedHints = listOf("已赞", "已点赞", "取消赞", "取消点赞", "已喜欢"),
        commentEntry = Target.desc("评论", "评论，按钮"),
        commentBox = Target.id("editor_view", "edit_text", "et_comment"),
        commentSend = Target.text("发送", "发布"),
        afterCommentBack = 2,
        launchWaitMs = 4500L,
        stepWaitMs = 1200L,
        backToHome = 3,
        builtIn = true
    )

    private val kuaishouLite = kuaishou.copy(
        id = "kuaishou_nebula",
        name = "快手极速版",
        pkg = "com.kuaishou.nebula"
    )

    private val bilibili = AppProfile(
        id = "bilibili",
        name = "哔哩哔哩",
        pkg = "tv.danmaku.bili",
        searchEntry = Target.desc("搜索", "搜索，按钮"),
        searchBox = Target.id("search_src_text", "et_search"),
        searchGo = Target.text("搜索"),
        resultTab = Target.text("视频"),
        firstResult = null,
        resultX = 0.5f,
        resultY = 0.35f,
        like = Target.desc("点赞", "赞", "给UP主点赞"),
        likedHints = listOf("已赞", "已点赞", "取消赞", "取消点赞"),
        commentEntry = Target.desc("评论", "评论，按钮"),
        commentBox = Target.id("et_content", "edit_text"),
        commentSend = Target.text("发送", "发布"),
        afterCommentBack = 2,
        launchWaitMs = 4500L,
        stepWaitMs = 1200L,
        backToHome = 3,
        builtIn = true
    )

    private val xiaohongshu = AppProfile(
        id = "xiaohongshu",
        name = "小红书",
        pkg = "com.xingin.xhs",
        searchEntry = Target.desc("搜索", "搜索，按钮"),
        searchBox = Target.id("search_input", "et_search", "edit_text"),
        searchGo = Target.text("搜索"),
        resultTab = Target.text("视频"),
        firstResult = null,
        resultX = 0.5f,
        resultY = 0.32f,
        like = Target.desc("点赞", "赞", "喜欢"),
        likedHints = listOf("已赞", "已点赞", "取消赞", "取消点赞", "已喜欢"),
        commentEntry = Target.desc("评论", "评论，按钮"),
        commentBox = Target.id("edit_text", "et_comment"),
        commentSend = Target.text("发送", "发布"),
        afterCommentBack = 2,
        launchWaitMs = 4500L,
        stepWaitMs = 1200L,
        backToHome = 3,
        builtIn = true
    )

    /** 万能兜底模板：只靠 desc/text 猜，适合先跑一遍看日志再微调 */
    private val generic = AppProfile(
        id = "generic",
        name = "通用（靠文案猜控件）",
        pkg = "",
        searchEntry = Target.desc("搜索", "搜索，按钮"),
        searchBox = null,
        searchGo = Target.text("搜索"),
        resultTab = Target.text("视频", "作品"),
        firstResult = null,
        resultX = 0.5f,
        resultY = 0.35f,
        like = Target.desc("点赞", "赞", "喜欢"),
        commentEntry = Target.desc("评论"),
        commentBox = null,
        commentSend = Target.text("发送", "发布"),
        afterCommentBack = 2,
        launchWaitMs = 5000L,
        stepWaitMs = 1500L,
        backToHome = 3,
        builtIn = true
    )

    fun builtIn(): List<AppProfile> =
        listOf(douyin, kuaishou, kuaishouLite, bilibili, xiaohongshu, generic)

    fun find(id: String, custom: List<AppProfile> = emptyList()): AppProfile? =
        (custom + builtIn()).firstOrNull { it.id == id }
}
