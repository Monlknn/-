package com.ujn.autodroid.model

import org.json.JSONObject

/**
 * 某个 App 的"操作模板"。
 * 所有控件都用 Target 描述，支持多候选词，因此换 App / 换版本只需改模板，不用改代码。
 *
 * 典型流程：
 *   启动 App → 点搜索入口 → 输入关键词 → 点搜索 → (点"视频"tab) → 点第一个结果
 *   → 循环 { 点赞 / 评论 → 上滑下一个 } → 返回
 */
data class AppProfile(
    val id: String,
    val name: String,
    val pkg: String,

    /** 首页搜索入口按钮 */
    val searchEntry: Target? = null,
    /** 搜索页输入框 */
    val searchBox: Target? = null,
    /** 搜索按钮（为空则尝试用输入法回车） */
    val searchGo: Target? = null,

    /** 结果页"视频/作品"筛选 tab，可为空 */
    val resultTab: Target? = null,
    /** 结果列表里第一个视频，可为空（为空则用 resultRegion 坐标点击） */
    val firstResult: Target? = null,
    /** 兜底坐标点击：屏幕宽/高的百分比 */
    val resultX: Float = 0.5f,
    val resultY: Float = 0.35f,

    /** 点赞按钮 */
    val like: Target? = null,
    /** 已经点过赞时的特征词，命中则跳过（避免误取消点赞） */
    val likedHints: List<String> = listOf("已赞", "已点赞", "取消赞", "取消点赞", "取消喜欢"),

    /** 评论入口按钮 */
    val commentEntry: Target? = null,
    /** 评论输入框 */
    val commentBox: Target? = null,
    /** 发送按钮 */
    val commentSend: Target? = null,
    /** 评论完成后按几次返回键收起评论面板 */
    val afterCommentBack: Int = 2,

    /** 启动后等待时间（毫秒） */
    val launchWaitMs: Long = 4000L,
    /** 每一次点击后的等待时间（毫秒） */
    val stepWaitMs: Long = 1200L,
    /** 一个关键词跑完后，返回首页需要按几次返回键 */
    val backToHome: Int = 3,
    /** 是否用上滑切换下一个视频；false 则点击"下一个"按钮（nextVideo） */
    val swipeNext: Boolean = true,
    val nextVideo: Target? = null,
    /** 自定义标记：内置模板不可删除 */
    val builtIn: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("pkg", pkg)
        putOpt("searchEntry", searchEntry?.toJson())
        putOpt("searchBox", searchBox?.toJson())
        putOpt("searchGo", searchGo?.toJson())
        putOpt("resultTab", resultTab?.toJson())
        putOpt("firstResult", firstResult?.toJson())
        put("resultX", resultX.toDouble())
        put("resultY", resultY.toDouble())
        putOpt("like", like?.toJson())
        put("likedHints", org.json.JSONArray().apply { likedHints.forEach { put(it) } })
        putOpt("commentEntry", commentEntry?.toJson())
        putOpt("commentBox", commentBox?.toJson())
        putOpt("commentSend", commentSend?.toJson())
        put("afterCommentBack", afterCommentBack)
        put("launchWaitMs", launchWaitMs)
        put("stepWaitMs", stepWaitMs)
        put("backToHome", backToHome)
        put("swipeNext", swipeNext)
        putOpt("nextVideo", nextVideo?.toJson())
        put("builtIn", builtIn)
    }

    companion object {
        fun fromJson(o: JSONObject): AppProfile {
            fun t(key: String): Target? = Target.fromJson(o.optJSONObject(key))
            val hints = ArrayList<String>()
            o.optJSONArray("likedHints")?.let { arr ->
                for (i in 0 until arr.length()) hints.add(arr.optString(i, ""))
            }
            return AppProfile(
                id = o.optString("id"),
                name = o.optString("name"),
                pkg = o.optString("pkg"),
                searchEntry = t("searchEntry"),
                searchBox = t("searchBox"),
                searchGo = t("searchGo"),
                resultTab = t("resultTab"),
                firstResult = t("firstResult"),
                resultX = o.optDouble("resultX", 0.5).toFloat(),
                resultY = o.optDouble("resultY", 0.35).toFloat(),
                like = t("like"),
                likedHints = if (hints.isEmpty()) listOf("已赞", "已点赞", "取消赞", "取消点赞") else hints,
                commentEntry = t("commentEntry"),
                commentBox = t("commentBox"),
                commentSend = t("commentSend"),
                afterCommentBack = o.optInt("afterCommentBack", 2),
                launchWaitMs = o.optLong("launchWaitMs", 4000L),
                stepWaitMs = o.optLong("stepWaitMs", 1200L),
                backToHome = o.optInt("backToHome", 3),
                swipeNext = o.optBoolean("swipeNext", true),
                nextVideo = t("nextVideo"),
                builtIn = o.optBoolean("builtIn", false)
            )
        }
    }
}
