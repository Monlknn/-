package com.ujn.autodroid.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import com.ujn.autodroid.R
import com.ujn.autodroid.core.PolicyController
import com.ujn.autodroid.model.AppProfile
import com.ujn.autodroid.model.Profiles
import com.ujn.autodroid.model.TaskConfig
import com.ujn.autodroid.service.AutoService
import com.ujn.autodroid.store.ConfigStore
import com.ujn.autodroid.util.LogBus
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvPermission: TextView
    private lateinit var spProfile: Spinner
    private lateinit var etPkg: EditText
    private lateinit var etKeywords: EditText
    private lateinit var swLike: SwitchCompat
    private lateinit var swComment: SwitchCompat
    private lateinit var etComments: EditText
    private lateinit var etCount: EditText
    private lateinit var etLoop: EditText
    private lateinit var etMinDelay: EditText
    private lateinit var etMaxDelay: EditText
    private lateinit var cbSkipLiked: CheckBox
    private lateinit var cbDryRun: CheckBox
    private lateinit var etWatchMin: EditText
    private lateinit var etWatchMax: EditText
    private lateinit var etSkipProb: EditText
    private lateinit var etOnlyLikeProb: EditText
    private lateinit var etOnlyCommentProb: EditText
    private lateinit var cbTypeChar: CheckBox
    private lateinit var etSessionMin: EditText
    private lateinit var etBreakMin: EditText
    private lateinit var etDailyLike: EditText
    private lateinit var etDailyComment: EditText
    private lateinit var etHourFrom: EditText
    private lateinit var etHourTo: EditText
    private lateinit var cbTimeWindow: CheckBox
    private lateinit var cbUniqueComment: CheckBox
    private lateinit var tvLog: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private var allProfiles: MutableList<AppProfile> = mutableListOf()

    private val logListener: (String) -> Unit = { appendLog(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPermission = findViewById(R.id.tvPermission)
        spProfile = findViewById(R.id.spProfile)
        etPkg = findViewById(R.id.etPkg)
        etKeywords = findViewById(R.id.etKeywords)
        swLike = findViewById(R.id.swLike)
        swComment = findViewById(R.id.swComment)
        etComments = findViewById(R.id.etComments)
        etCount = findViewById(R.id.etCount)
        etLoop = findViewById(R.id.etLoop)
        etMinDelay = findViewById(R.id.etMinDelay)
        etMaxDelay = findViewById(R.id.etMaxDelay)
        cbSkipLiked = findViewById(R.id.cbSkipLiked)
        cbDryRun = findViewById(R.id.cbDryRun)
        etWatchMin = findViewById(R.id.etWatchMin)
        etWatchMax = findViewById(R.id.etWatchMax)
        etSkipProb = findViewById(R.id.etSkipProb)
        etOnlyLikeProb = findViewById(R.id.etOnlyLikeProb)
        etOnlyCommentProb = findViewById(R.id.etOnlyCommentProb)
        cbTypeChar = findViewById(R.id.cbTypeChar)
        etSessionMin = findViewById(R.id.etSessionMin)
        etBreakMin = findViewById(R.id.etBreakMin)
        etDailyLike = findViewById(R.id.etDailyLike)
        etDailyComment = findViewById(R.id.etDailyComment)
        etHourFrom = findViewById(R.id.etHourFrom)
        etHourTo = findViewById(R.id.etHourTo)
        cbTimeWindow = findViewById(R.id.cbTimeWindow)
        cbUniqueComment = findViewById(R.id.cbUniqueComment)
        tvLog = findViewById(R.id.tvLog)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        reloadProfiles()
        fillForm(ConfigStore.loadTask(this))

        findViewById<View>(R.id.btnPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnStart.setOnClickListener { startTask() }
        btnStop.setOnClickListener {
            AutoService.instance?.stopTask()
            Toast.makeText(this, "已发送停止指令", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnSave).setOnClickListener {
            ConfigStore.saveTask(this, collectConfig())
            Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnProbe).setOnClickListener { probe() }
        findViewById<View>(R.id.btnCopyLog).setOnClickListener { copyLog() }
        findViewById<View>(R.id.btnQuota).setOnClickListener {
            val c = collectConfig()
            appendLog(PolicyController(this).quotaSummary(c))
            Toast.makeText(this, PolicyController(this).quotaSummary(c), Toast.LENGTH_LONG).show()
        }
        findViewById<View>(R.id.btnResetQuota).setOnClickListener {
            PolicyController(this).resetToday()
            appendLog("今日配额已重置")
            Toast.makeText(this, "今日配额已重置", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnAddTemplate).setOnClickListener {
            TemplateDialog.show(this) { p ->
                val list = ConfigStore.loadCustom(this).toMutableList()
                list.removeAll { it.id == p.id }
                list.add(p)
                ConfigStore.saveCustom(this, list)
                reloadProfiles()
                selectProfile(p.id)
                Toast.makeText(this, "模板已保存：${p.name}", Toast.LENGTH_SHORT).show()
            }
        }

        spProfile.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: android.widget.AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val p = allProfiles.getOrNull(position) ?: return
                if (etPkg.text.isNullOrBlank() || allProfiles.any { it.pkg == etPkg.text.toString() }) {
                    etPkg.setText(p.pkg)
                }
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100
                )
            }
        }

        AutoService.onStateChange = { runOnUiThread { refreshStatus() } }
        tvLog.text = LogBus.snapshot().ifEmpty { "等待操作…\n" }
        logBuffer.append(tvLog.text)
        appendLog("提示：先点【探测当前界面控件】确认能读到屏幕，再配置模板。")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        // 只在这里注册，与 onPause 的注销严格配对；
        // 之前在 onCreate 里也注册过一次，导致反复切页面后日志会重复打印。
        LogBus.addListener(logListener)
        // 断开期间产生的日志补进来，避免回到前台后日志区是空的
        val snapshot = LogBus.snapshot()
        if (snapshot.isNotEmpty() && !logBuffer.endsWith(snapshot)) {
            logBuffer.setLength(0)
            logBuffer.append(snapshot)
            if (logBuffer.length > 12000) logBuffer.delete(0, logBuffer.length - 12000)
        }
        scheduleLogFlush()
    }

    override fun onPause() {
        LogBus.removeListener(logListener)
        super.onPause()
    }

    override fun onDestroy() {
        LogBus.removeListener(logListener)
        AutoService.onStateChange = null
        super.onDestroy()
    }

    // ---------- 配置读写 ----------

    private fun reloadProfiles() {
        val custom = ConfigStore.loadCustom(this)
        allProfiles = (custom + Profiles.builtIn()).toMutableList()
        spProfile.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            allProfiles.map { "${it.name}${if (it.builtIn) "" else "（自定义）"}" }
        )
    }

    private fun selectProfile(id: String) {
        val idx = allProfiles.indexOfFirst { it.id == id }
        if (idx >= 0) spProfile.setSelection(idx)
    }

    private fun currentProfile(): AppProfile =
        allProfiles.getOrNull(spProfile.selectedItemPosition) ?: Profiles.builtIn().first()

    private fun fillForm(c: TaskConfig) {
        selectProfile(c.profileId)
        etPkg.setText(c.pkg.ifBlank { currentProfile().pkg })
        etKeywords.setText(c.keywords.joinToString("\n"))
        swLike.isChecked = c.doLike
        swComment.isChecked = c.doComment
        etComments.setText(c.comments.joinToString("\n"))
        etCount.setText(c.videosPerKeyword.toString())
        etLoop.setText(c.loopCount.toString())
        etMinDelay.setText(c.delayMedianMs.toString())
        etMaxDelay.setText(c.delaySigma.toString())
        cbSkipLiked.isChecked = c.skipIfLiked
        cbDryRun.isChecked = c.dryRun

        etWatchMin.setText(c.watchMinMs.toString())
        etWatchMax.setText(c.watchMaxMs.toString())
        etSkipProb.setText(c.skipVideoProb.toString())
        etOnlyLikeProb.setText(c.onlyLikeProb.toString())
        etOnlyCommentProb.setText(c.onlyCommentProb.toString())
        cbTypeChar.isChecked = c.typeCharByChar
        etSessionMin.setText(c.sessionMinutes.toString())
        etBreakMin.setText(c.breakMinutes.toString())
        etDailyLike.setText(c.dailyLikeLimit.toString())
        etDailyComment.setText(c.dailyCommentLimit.toString())
        etHourFrom.setText(c.hourFrom.toString())
        etHourTo.setText(c.hourTo.toString())
        cbTimeWindow.isChecked = c.respectTimeWindow
        cbUniqueComment.isChecked = c.uniqueComment
    }

    private fun collectConfig(): TaskConfig {
        fun lines(et: EditText, def: List<String>): List<String> {
            val l = et.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
            return if (l.isEmpty()) def else l
        }

        fun d(et: EditText, def: Double): Double =
            et.text.toString().toDoubleOrNull() ?: def

        fun l(et: EditText, def: Long): Long =
            et.text.toString().toLongOrNull() ?: def

        fun i(et: EditText, def: Int): Int =
            et.text.toString().toIntOrNull() ?: def

        return TaskConfig(
            profileId = currentProfile().id,
            pkg = etPkg.text.toString().trim(),
            keywords = lines(etKeywords, listOf("风景")),
            doLike = swLike.isChecked,
            doComment = swComment.isChecked,
            comments = lines(etComments, listOf("拍得真好")),
            videosPerKeyword = i(etCount, 3).coerceIn(1, 999),
            loopCount = i(etLoop, 1).coerceIn(1, 99),
            delayMedianMs = l(etMinDelay, 2200L).coerceIn(300L, 60000L),
            delaySigma = d(etMaxDelay, 0.55).coerceIn(0.05, 1.5),
            watchMinMs = l(etWatchMin, 3000L).coerceIn(0L, 300000L),
            watchMaxMs = l(etWatchMax, 12000L).coerceIn(0L, 600000L),
            skipVideoProb = d(etSkipProb, 0.12).coerceIn(0.0, 1.0),
            onlyLikeProb = d(etOnlyLikeProb, 0.35).coerceIn(0.0, 1.0),
            onlyCommentProb = d(etOnlyCommentProb, 0.10).coerceIn(0.0, 1.0),
            typeCharByChar = cbTypeChar.isChecked,
            sessionMinutes = i(etSessionMin, 25).coerceIn(0, 600),
            breakMinutes = i(etBreakMin, 8).coerceIn(0, 120),
            dailyLikeLimit = i(etDailyLike, 50).coerceIn(0, 10000),
            dailyCommentLimit = i(etDailyComment, 10).coerceIn(0, 10000),
            hourFrom = i(etHourFrom, 8).coerceIn(0, 23),
            hourTo = i(etHourTo, 23).coerceIn(0, 23),
            respectTimeWindow = cbTimeWindow.isChecked,
            uniqueComment = cbUniqueComment.isChecked,
            skipIfLiked = cbSkipLiked.isChecked,
            dryRun = cbDryRun.isChecked
        )
    }

    // ---------- 动作 ----------

    private fun startTask() {
        if (!AutoService.isEnabled(this)) {
            Toast.makeText(this, "请先开启无障碍服务", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val svc = AutoService.instance
        if (svc == null) {
            Toast.makeText(this, "服务未连接，请到设置里关闭再打开本服务", Toast.LENGTH_LONG).show()
            return
        }
        if (AutoService.running) {
            Toast.makeText(this, "任务已在运行", Toast.LENGTH_SHORT).show()
            return
        }
        val cfg = collectConfig()
        if (cfg.pkg.isBlank()) {
            Toast.makeText(this, "请填写目标 App 包名", Toast.LENGTH_LONG).show()
            etPkg.error = "包名不能为空"
            return
        }
        // 提前校验包名是否真实安装，避免任务跑起来才发现拉不起 App
        val launchable = runCatching {
            packageManager.getLaunchIntentForPackage(cfg.pkg) != null
        }.getOrDefault(false)
        if (!launchable) {
            etPkg.error = "未检测到该 App，请确认包名"
            Toast.makeText(this, "未检测到应用：${cfg.pkg}", Toast.LENGTH_LONG).show()
            appendLog("× 包名校验失败：未安装或无启动入口 → ${cfg.pkg}")
            return
        }
        if (!cfg.doLike && !cfg.doComment) {
            Toast.makeText(this, "至少勾选点赞或评论其中一个", Toast.LENGTH_LONG).show()
            return
        }
        if (cfg.doComment && cfg.comments.isEmpty()) {
            Toast.makeText(this, "勾选了评论但评论内容为空", Toast.LENGTH_LONG).show()
            return
        }
        ConfigStore.saveTask(this, cfg)
        svc.startTask(cfg, currentProfile())
        refreshStatus()
    }

    private fun probe() {
        val svc = AutoService.instance
        if (svc == null) {
            Toast.makeText(this, "无障碍服务未连接", Toast.LENGTH_SHORT).show()
            return
        }
        val nodes = svc.dumpCurrent(120)
        if (nodes.isEmpty()) {
            appendLog("探测失败：读不到当前窗口（服务未开启或当前页面无内容）")
            return
        }
        val sb = StringBuilder("── 当前界面控件（前 ${nodes.size} 个）──\n")
        nodes.forEachIndexed { i, n ->
            sb.append(String.format("%02d ", i))
            if (n.id.isNotEmpty()) sb.append("id=").append(n.id.substringAfterLast('/')).append("  ")
            if (n.text.isNotEmpty()) sb.append("text=").append(n.text.take(20)).append("  ")
            if (n.desc.isNotEmpty()) sb.append("desc=").append(n.desc.take(20)).append("  ")
            if (n.clickable) sb.append("[可点击] ")
            if (n.editable) sb.append("[可输入] ")
            sb.append(n.bounds.toShortString()).append('\n')
        }
        val file = File(filesDir, "probe.txt")
        runCatching { file.writeText(sb.toString()) }
        appendLog(sb.toString())
        Toast.makeText(this, "已 dump ${nodes.size} 个控件，详见日志", Toast.LENGTH_SHORT).show()
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("autodroid-log", LogBus.snapshot()))
        Toast.makeText(this, "日志已复制到剪贴板", Toast.LENGTH_SHORT).show()
    }

    /** UI 日志缓冲区，避免每次都读写 tvLog.text（整段字符串拷贝 + 触发重排） */
    private val logBuffer = StringBuilder()
    private var logDirty = false

    /**
     * 追加日志。
     * 高频 append 时每次都读 tvLog.text 做长度裁剪会带来 O(n) 拷贝，
     * 这里改为维护独立缓冲，并合并刷新，降低长任务下的 UI 开销。
     */
    private fun appendLog(line: String) {
        logBuffer.append(line)
        if (!line.endsWith("\n")) logBuffer.append("\n")
        if (logBuffer.length > 12000) {
            logBuffer.delete(0, logBuffer.length - 12000)
        }
        scheduleLogFlush()
    }

    private val flushRunnable = Runnable {
        logDirty = false
        tvLog.text = logBuffer.toString()
        // 滚到底部，保证用户看到最新一行。
        // tvLog 的直接父级是 LinearLayout，真正的滚动容器在更上层，所以要向上查找。
        var p: android.view.ViewParent? = tvLog.parent
        var guard = 0
        while (p != null && guard++ < 6) {
            if (p is android.widget.ScrollView) {
                runCatching { p.fullScroll(View.FOCUS_DOWN) }
                break
            }
            p = p.parent
        }
    }

    private fun scheduleLogFlush() {
        if (logDirty) return
        logDirty = true
        tvLog.postDelayed(flushRunnable, 120L)
    }

    private fun refreshStatus() {
        val enabled = AutoService.isEnabled(this)
        val running = AutoService.running
        tvPermission.text = when {
            !enabled -> "无障碍服务：未开启"
            running -> "无障碍服务：已开启 · 任务运行中"
            else -> "无障碍服务：已开启 · 空闲"
        }
        tvPermission.setTextColor(
            if (enabled) 0xFF2E7D32.toInt() else 0xFFD32F2F.toInt()
        )
        btnStart.isEnabled = !running
        btnStop.isEnabled = running
    }
}
